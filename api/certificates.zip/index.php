<?php
error_reporting(E_ALL);
echo $veribd;
// $con = mysqli_init();
// // mysqli_ssl_set($con, NULL, NULL, "/DigiCertGlobalRootCA.crt.pem", NULL, NULL);
// mysqli_real_connect($con, "nirmaan-learning-portal-api-server.mysql.database.azure.com", "jxrgfrymip", "zxcvbnmLP123.", "learning", 3306);
// if (mysqli_connect_errno($con)) {
//     die('Failed to connect to MySQL: ' . mysqli_connect_error());
// }
// //Close the connection , MYSQLI_CLIENT_SSL
// mysqli_close($con);
?>